#include "BIS_AddonInfo.hpp"
class CfgPatches {
    class 53rd_Weapons_Ammo{
        units[] = {};
		weapons[] = {};
		requiredAddons[] = {"OPTRE_Core","A3_Weapons_F"};
		author = "Frankenburg";
    }

};
#include "cfgAmmo.hpp"
#include "cfgMagazines.hpp"