class BIS_AddonInfo
{
	author="Body";
	timepacked="1717024085";
};
