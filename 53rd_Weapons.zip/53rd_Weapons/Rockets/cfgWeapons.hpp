class CfgWeapons{
    //This is a stupid hack because prccusors redefines the Class.
    class OPTRE_UnguidedLauncher_Base;

    class OPTRE_M41_SSR: OPTRE_UnguidedLauncher_Base{
        magazines[] += {""};

    };
};